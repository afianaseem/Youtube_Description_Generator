# 📝 iboothme YouTube Description Generator

This project uses a Jupyter Notebook to:
- Upload or download a video (YouTube or direct `.mp4`)
- Transcribe the audio using Whisper
- Analyze video frames if audio is not usable
- Generate a professional, iboothme-style YouTube description using OpenRouter (Mistral model)

---

## 🔧 Setup

Install dependencies:

```bash
pip install gradio openai yt_dlp ffmpeg-python requests
pip install git+https://github.com/openai/whisper.git

Set FFmpeg path in the notebook:

python
'ffmpeg_location': r'C:\Path\To\ffmpeg\bin\ffmpeg.exe'

Set temp directory to E:/temp automatically in code.

## 🔐OpenRouter API:
Get an API key from https://openrouter.ai and input it when prompted:

python
api_key = getpass.getpass("Enter your OpenRouter API key:")

## 🚀 Run:
Launch the interface in the notebook:

python
interface.launch(share=True, inline=False)

Then:

Select Upload to drag a local video
Or choose URL to paste a YouTube/direct MP4 link
Click Generate Description

## 📦 Tech Stack:
openai/whisper – video transcription

mistral-7b-instruct – description generation

yt_dlp – YouTube download

ffmpeg-python – video validation

gradio – UI 

## 📁 File:
_intership.ipynb – main notebook


